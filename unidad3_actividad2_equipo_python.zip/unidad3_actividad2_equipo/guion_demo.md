# Guion de demostración · Parcial III
**Duración:** 5 a 7 minutos · **Responsables:** (completar por integrante)

1. **Presentación (30 s).** Nombre del equipo, integrantes y qué hace el sistema: un dashboard que lee los balances del backend.
2. **Arquitectura (1 min).** Mostrar el diagrama o boceto: backend en Python (FastAPI + Strawberry GraphQL), PostgreSQL en Docker (o SQLite) y dashboard que consume `/graphql` con Bearer token.
3. **Login (1 min).** Entrar con el usuario de prueba. Mostrar que la mutación `login` devuelve el token.
4. **Indicadores (1.5 min).** Período 26–30 de octubre de 2026. Señalar cada tarjeta y decir de qué campo GraphQL sale (`openingBalance`, `totalIncome`, `totalExpense`, `profit`, `closingBalance`).
5. **Riesgo y detalle (1.5 min).** Mostrar "General en rojo: No" y "Cuentas en rojo: 1". Explicar que Caja está en rojo mientras el saldo general sigue positivo.
6. **Cambio de fechas (1 min).** Cambiar el período y pulsar Actualizar. Mostrar que el período visible cambia junto con los números.
7. **Caso de error (30 s).** Mostrar un token inválido o un usuario sin permiso y el mensaje que ve el usuario.
8. **Cierre (30 s).** Cerrar sesión y resumir lo aprendido.
