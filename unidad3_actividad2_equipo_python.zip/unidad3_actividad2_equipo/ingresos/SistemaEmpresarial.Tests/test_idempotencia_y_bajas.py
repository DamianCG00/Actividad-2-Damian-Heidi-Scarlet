import os
import sqlite3
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "SistemaEmpresarial")))

import strawberry
from Acceso import AccessSeeder, JwtService
from Data import AppDbContext
from GraphQL import Mutation, Query


class IdempotenciaYBajasTests(unittest.TestCase):
    def setUp(self):
        self.conn = sqlite3.connect(":memory:", isolation_level=None)
        self.db = AppDbContext(self.conn)
        self.db.ensure_created()
        AccessSeeder.seed(self.db)
        self.cfg = {"Jwt": {"Key": "clave_secreta_desarrollo_sistema_empresarial_32chars",
                            "Issuer": "SistemaEmpresarial", "Audience": "dashboard"}}
        self.schema = strawberry.Schema(query=Query, mutation=Mutation)
        self.actor, self.company_id, self.cuenta_id, self.ingreso_id = self._preparar()

    def tearDown(self):
        self.conn.close()

    def _exec(self, query, variables=None, token=None):
        claims = JwtService.validar(token, self.cfg) if token else None
        ctx = {"db": self.db, "config": self.cfg, "claims": claims}
        return self.schema.execute_sync(query, variable_values=variables or {}, context_value=ctx)

    def _preparar(self):
        r = self._exec('mutation { createCompany(input: { name: "Empresa Demo" }) { id } }')
        cid = r.data["createCompany"]["id"]
        self._exec("""mutation($cid: String!) { createAdmin(input: {
            companyId: $cid, name: "Admin", email: "admin@demo.com", password: "password123" }) { id } }""",
                   {"cid": cid})
        login = self._exec("""mutation Login($input: LoginInput!) {
            login(input: $input) { success token } }""",
                           {"input": {"email": "admin@demo.com", "password": "password123"}})
        claims = JwtService.validar(login.data["login"]["token"], self.cfg)
        actor = claims["companyUserId"]
        cuenta = self._exec("""mutation($a: String!, $c: String!) { createAccount(actorCompanyUserId: $a,
            input: { companyId: $c, accountType: DEBIT, name: "Banco" }) { id } }""",
                            {"a": actor, "c": cid}).data["createAccount"]["id"]
        ingreso = self._exec("""mutation($a: String!, $c: String!) { createConcept(actorCompanyUserId: $a,
            input: { companyId: $c, conceptType: INCOME, name: "Ventas" }) { id } }""",
                             {"a": actor, "c": cid}).data["createConcept"]["id"]
        egreso = self._exec("""mutation($a: String!, $c: String!) { createConcept(actorCompanyUserId: $a,
            input: { companyId: $c, conceptType: EXPENSE, name: "Gastos" }) { id } }""",
                            {"a": actor, "c": cid}).data["createConcept"]["id"]
        for concepto in (ingreso, egreso):
            self._exec("""mutation($a: String!, $ac: String!, $co: String!) { assignConceptToAccount(
                actorCompanyUserId: $a, input: { accountId: $ac, conceptId: $co }) { id } }""",
                       {"a": actor, "ac": cuenta, "co": concepto})
        return actor, cid, cuenta, ingreso

    def _crear_movimiento(self, key, monto=50, desc="Venta"):
        return self._exec("""mutation($a: String!, $ac: String!, $co: String!, $m: Decimal!, $k: String, $d: String) {
            createTransaction(actorCompanyUserId: $a, input: { accountId: $ac, conceptId: $co,
              transactionType: INCOME, amount: $m, shortDescription: $d, idempotencyKey: $k }) { id amount } }""",
                          {"a": self.actor, "ac": self.cuenta_id, "co": self.ingreso_id,
                           "m": monto, "k": key, "d": desc})

    def _conteo_movimientos(self):
        return self.conn.execute('SELECT COUNT(*) FROM "Transactions"').fetchone()[0]

    def test_misma_llave_devuelve_el_mismo_movimiento(self):
        r1 = self._crear_movimiento("llave-001")
        r2 = self._crear_movimiento("llave-001")
        self.assertIsNone(r1.errors)
        self.assertIsNone(r2.errors)
        self.assertEqual(r1.data["createTransaction"]["id"], r2.data["createTransaction"]["id"])
        self.assertEqual(self._conteo_movimientos(), 1)

    def test_llave_distinta_crea_otro_movimiento_aunque_el_monto_sea_igual(self):
        r1 = self._crear_movimiento("llave-001")
        r2 = self._crear_movimiento("llave-002")
        self.assertNotEqual(r1.data["createTransaction"]["id"], r2.data["createTransaction"]["id"])
        self.assertEqual(self._conteo_movimientos(), 2)

    def test_misma_llave_con_otros_datos_se_rechaza(self):
        self._crear_movimiento("llave-001", monto=50)
        r2 = self._crear_movimiento("llave-001", monto=75)
        self.assertIsNotNone(r2.errors)
        self.assertIn("ya se usó con otros datos", r2.errors[0].message)
        self.assertEqual(self._conteo_movimientos(), 1)

    def test_sin_llave_cada_envio_crea_movimiento(self):
        self._crear_movimiento(None)
        self._crear_movimiento(None)
        self.assertEqual(self._conteo_movimientos(), 2)

    def test_baja_logica_de_membresia_y_administrador_protegido(self):
        r_user = self._exec("""mutation($a: String!, $c: String!) { createUser(actorCompanyUserId: $a,
            input: { companyId: $c, name: "Luis", email: "luis@demo.mx", password: "Demo2026!" }) { id } }""",
                            {"a": self.actor, "c": self.company_id})
        self.assertIsNone(r_user.errors)
        membresias = self._exec("""query($a: String!, $c: String!) { companyUsers(actorCompanyUserId: $a,
            companyId: $c) { id isAdmin isActive } }""", {"a": self.actor, "c": self.company_id})
        self.assertIsNone(membresias.errors)
        no_admin = [m for m in membresias.data["companyUsers"] if not m["isAdmin"]][0]
        admin = [m for m in membresias.data["companyUsers"] if m["isAdmin"]][0]

        baja = self._exec("""mutation($cu: String!, $a: String!) { deactivateCompanyUser(
            companyUserId: $cu, actorCompanyUserId: $a) { id isActive } }""",
                          {"cu": no_admin["id"], "a": self.actor})
        self.assertIsNone(baja.errors)
        self.assertFalse(baja.data["deactivateCompanyUser"]["isActive"])

        bloqueo = self._exec("""mutation($cu: String!, $a: String!) { deactivateCompanyUser(
            companyUserId: $cu, actorCompanyUserId: $a) { id isActive } }""",
                             {"cu": admin["id"], "a": self.actor})
        self.assertIsNotNone(bloqueo.errors)
        self.assertIn("administrador principal", bloqueo.errors[0].message)


if __name__ == "__main__":
    unittest.main()
